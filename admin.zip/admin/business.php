<!DOCTYPE html>
<html lang="en">
    <head>
        <?php include 'style.php'?>
    </head>

    <body>
        <!-- ============================================================== -->
        <!-- main wrapper -->
        <!-- ============================================================== -->
        <div class="dashboard-main-wrapper">
            <!-- ============================================================== -->
            <!-- navbar -->
            <!-- ============================================================== -->
            <div class="dashboard-header">
                <?php include 'nav.php'?>
            </div>
            <!-- ============================================================== -->
            <!-- end navbar -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- left sidebar -->
            <!-- ============================================================== -->
            <div class="nav-left-sidebar sidebar-dark">
                <div class="menu-list">
                    <?php include 'menu.php'?>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- end left sidebar -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- wrapper  -->
            <!-- ============================================================== -->
            <div class="dashboard-wrapper">
                <div class="container dashboard-content">
                    <!-- ============================================================== -->
                    <!-- pagehader  -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <h3 class="mb-2">Business</h3>

                                <div class="page-breadcrumb">
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">ASE Admin</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Business</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <!-- /. metric -->
                        <!-- metric -->
                    </div>
                    <!-- /. metric -->
                    <!-- metric -->

                    <!-- /. metric -->

                    <!-- ============================================================== -->
                    <!-- revenue  -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <!-- ============================================================== -->
                        <!-- end reveune  -->
                        <!-- ============================================================== -->
                        <!-- ============================================================== -->
                        <!-- total sale  -->
                        <!-- ============================================================== -->
                        <div class="col-xl-12 col-lg-12 col-md-5 col-sm-12 col-12">
                            <div class="card">
                                <div id="exTab1" class="container">
                                    <ul class="nav nav-pills">
                                        <li>
                                            <a href="#1a" data-toggle="tab">Enter Amount Details</a>
                                        </li>
                                        <li>
                                            <a href="#2a" data-toggle="tab">Business Summary</a>
                                        </li>
                                        <li><a href="#3a" data-toggle="tab"> Business Transactions</a></li>
                                    </ul>
                                    <div class="card-body">
                                        <div class="">
                                            <div class="tab-content clearfix">
                                                <div class="tab-pane active" id="1a">
                                                    <div class="row">
                                                        <div class="col-md-6 offset-md-3">
                                                            <form action="#" method="post">
                                                        <div class="form-group col-md-12">
                                                            <input type="text" class="form-control" required="" placeholder="Enter Customer ID" name="customer-id" />
                                                        </div>
                                                        <div class="form-group col-md-12">
                                                            <input type="text" class="form-control" required="" placeholder="Amount Paid" name="paidamount" />
                                                        </div>

                                                        <div class="form-group col-md-12 text-center">
                                                            <input type="submit" value="Submit" class="btn btn-default btn-radius logs" />
                                                        </div>
                                                    </form>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="2a">
                                                    <div class="input-group col-md-6 search">
                                                        <input type="text" class="form-control" placeholder="Enter Your ID" />
                                                        <div class="input-group-append">
                                                            <button class="btn btn-secondary" type="button">
                                                                <i class="fa fa-search"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                    <div class="row business">
                                                        <!-- metric -->
                                                        <div class="col-lg-4 col-md-2 col-sm-12 col-12">
                                                            <div class="card">
                                                                <div class="card-body">
                                                                    <h5 class="text-muted">Total Amount</h5>
                                                                    <div class="metric-value d-inline-block">
                                                                        <h1 class="mb-1 text-primary">32,100</h1>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- /. metric -->
                                                        <!-- metric -->
                                                        <div class="col-lg-4 col-md-2 col-sm-12 col-12">
                                                            <div class="card">
                                                                <div class="card-body">
                                                                    <h5 class="text-muted">Paid Amount</h5>
                                                                    <div class="metric-value d-inline-block">
                                                                        <h1 class="mb-1 text-primary">4,200</h1>
                                                                    </div>
                                                                    <div class="metric-label d-inline-block float-right text-danger"></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- /. metric -->
                                                        <!-- metric -->
                                                        <div class="col-lg-4 col-md-2 col-sm-12 col-12">
                                                            <div class="card">
                                                                <div class="card-body">
                                                                    <h5 class="text-muted">Pending Amount</h5>
                                                                    <div class="metric-value d-inline-block">
                                                                        <h1 class="mb-1 text-primary">5,656</h1>
                                                                    </div>
                                                                    <div class="metric-label d-inline-block float-right text-danger"></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- metric -->

                                                        <!-- /. metric -->
                                                        <!-- metric -->
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="3a">
                                                    <div class="input-group col-md-6 search">
                                                        <input type="text" class="form-control" placeholder="Enter Your ID" />
                                                        <div class="input-group-append">
                                                            <button class="btn btn-secondary" type="button">
                                                                <i class="fa fa-search"></i>
                                                            </button>
                                                        </div>
                                                    </div>

                                                    <table class="table status">
                                                        <thead>
                                                            <th>S.No</th>
                                                            <th>Member Name</th>
                                                            <th>Amount</th>
                                                            <th>Transaction Date</th>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td>1</td>
                                                                <td>
                                                                    <div class="margin-wallet-img">
                                                                        <h5>CamrynKonopelski</h5>
                                                                        <span class="sub-text">ASE1001</span>
                                                                    </div>
                                                                </td>
                                                                <td>400000</td>
                                                                <td>January 18, 2021, 2:07 pm</td>
                                                            </tr>
                                                            <tr>
                                                                <td>2</td>
                                                                <td>
                                                                    <div class="margin-wallet-img">
                                                                        <h5>CamrynKonopelski</h5>
                                                                        <span class="sub-text">ASE1002</span>
                                                                    </div>
                                                                </td>
                                                                <td>450000</td>
                                                                <td>January 18, 2021, 2:07 pm</td>
                                                            </tr>
                                                            <tr>
                                                                <td>3</td>
                                                                <td>
                                                                    <div class="margin-wallet-img">
                                                                        <h5>CamrynKonopelski</h5>
                                                                        <span class="sub-text">ASE1003</span>
                                                                    </div>
                                                                </td>
                                                                <td>450000</td>
                                                                <td>January 18, 2021, 2:07 pm</td>
                                                            </tr>
                                                            <tr>
                                                                <td>4</td>
                                                                <td>
                                                                    <div class="margin-wallet-img">
                                                                        <h5>CamrynKonopelski</h5>
                                                                        <span class="sub-text">ASE1004</span>
                                                                    </div>
                                                                </td>
                                                                <td>450000</td>
                                                                <td>January 18, 2021, 2:07 pm</td>
                                                            </tr>
                                                            <tr>
                                                                <td>5</td>
                                                                <td>
                                                                    <div class="margin-wallet-img">
                                                                        <h5>CamrynKonopelski</h5>
                                                                        <span class="sub-text">ASE1002</span>
                                                                    </div>
                                                                </td>
                                                                <td>450000</td>
                                                                <td>January 18, 2021, 2:07 pm</td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <nav aria-label="Page navigation example">
                                                        <ul class="pagination">
                                                            <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                                                            <li class="page-item"><a class="page-link" href="#">1</a></li>
                                                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                                                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                                                            <li class="page-item"><a class="page-link" href="#">Next</a></li>
                                                        </ul>
                                                    </nav>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end total sale  -->
                        <!-- ============================================================== -->
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- footer -->
                <!-- ============================================================== -->
                <div class="footer">
                    <?php include 'footer.php';?>
                </div>
                <!-- ============================================================== -->
                <!-- end footer -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- end wrapper  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- end main wrapper  -->
        <!-- ============================================================== -->
        <!-- Optional JavaScript -->
        <!-- jquery 3.3.1 js-->
        <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
        <!-- bootstrap bundle js-->
        <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
        <!-- slimscroll js-->
        <script src="assets/vendor/slimscroll/jquery.slimscroll.js"></script>
        <!-- chartjs js-->
        <script src="assets/vendor/charts/charts-bundle/Chart.bundle.js"></script>
        <script src="assets/vendor/charts/charts-bundle/chartjs.js"></script>

        <!-- main js-->
        <script src="assets/libs/js/main-js.js"></script>
        <!-- jvactormap js-->
        <script src="assets/vendor/jvectormap/jquery-jvectormap-2.0.2.min.js"></script>
        <script src="assets/vendor/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
        <!-- sparkline js-->
        <script src="assets/vendor/charts/sparkline/jquery.sparkline.js"></script>
        <script src="assets/vendor/charts/sparkline/spark-js.js"></script>
        <!-- dashboard sales js-->
        <script src="assets/libs/js/dashboard-sales.js"></script>
    </body>
</html>
