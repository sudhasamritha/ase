₹ <!DOCTYPE html>
<html lang="en">
    <head>
        <?php include 'style.php'?>
    </head>

    <body>
        <!-- ============================================================== -->
        <!-- main wrapper -->
        <!-- ============================================================== -->
        <div class="dashboard-main-wrapper">
            <!-- ============================================================== -->
            <!-- navbar -->
            <!-- ============================================================== -->
            <div class="dashboard-header">
                 <?php include 'nav.php'?>
            </div>
            <!-- ============================================================== -->
            <!-- end navbar -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- left sidebar -->
            <!-- ============================================================== -->
            <div class="nav-left-sidebar sidebar-dark">
                <div class="menu-list">
                    <?php include 'menu.php'?>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- end left sidebar -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- wrapper  -->
            <!-- ============================================================== -->
            <div class="dashboard-wrapper">
                <div class="container dashboard-content">
                    <!-- ============================================================== -->
                    <!-- pagehader  -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <h3 class="mb-2">Dashboard</h3>

                                <div class="page-breadcrumb">
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">ASE Admin</a></li>
                                            <li class="breadcrumb-item active" aria-current="page"></li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- pagehader  -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <!-- metric -->
                        <div class="col-lg-2 col-md-2 col-sm-12 col-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="dropdown options">
                                        <span class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fa fa-angle-right"></i>
                                        </span>
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                            <a class="dropdown-item" href="#">Week</a>
                                            <a class="dropdown-item" href="#">Month</a>
                                            <a class="dropdown-item" href="#">Year</a>
                                        </div>
                                    </div>
                                    <h5 class="text-muted">Income</h5>
                                    <div class="metric-value d-inline-block">
                                        <h1 class="mb-1 text-primary">32,100</h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /. metric -->
                        <!-- metric -->
                        <div class="col-lg-2 col-md-2 col-sm-12 col-12">
                            <div class="card">
                                <div class="card-body">
                                     <div class="dropdown options">
                                        <span class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fa fa-angle-right"></i>
                                        </span>
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                            <a class="dropdown-item" href="#">Week</a>
                                            <a class="dropdown-item" href="#">Month</a>
                                            <a class="dropdown-item" href="#">Year</a>
                                        </div>
                                    </div>
                                    <h5 class="text-muted">Paid</h5>
                                    <div class="metric-value d-inline-block">
                                        <h1 class="mb-1 text-primary">4,200</h1>
                                    </div>
                                    <div class="metric-label d-inline-block float-right text-danger"></div>
                                </div>
                            </div>
                        </div>
                        <!-- /. metric -->
                        <!-- metric -->
                        <div class="col-lg-2 col-md-2 col-sm-12 col-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="dropdown options">
                                        <span class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fa fa-angle-right"></i>
                                        </span>
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                            <a class="dropdown-item" href="#">Week</a>
                                            <a class="dropdown-item" href="#">Month</a>
                                            <a class="dropdown-item" href="#">Year</a>
                                        </div>
                                    </div>
                                    <h5 class="text-muted">Pending Amount</h5>
                                    <div class="metric-value d-inline-block">
                                        <h1 class="mb-1 text-primary">5,656</h1>
                                    </div>
                                    <div class="metric-label d-inline-block float-right text-danger"></div>
                                </div>
                            </div>
                        </div>
                        <!-- metric -->
                        <div class="col-lg-2 col-md-2 col-sm-12 col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="text-muted">Package</h5>
                                    <div class="dropdown options">
                                        <span class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fa fa-angle-right"></i>
                                        </span>
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                            <a class="dropdown-item" href="#">Week</a>
                                            <a class="dropdown-item" href="#">Month</a>
                                            <a class="dropdown-item" href="#">Year</a>
                                        </div>
                                    </div>
                                    <div class="metric-value d-inline-block">
                                        <h1 class="mb-1 text-primary">32,100</h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /. metric -->
                        <!-- metric -->
                        <div class="col-lg-2 col-md-2 col-sm-12 col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="text-muted">Profit</h5>
                                    <div class="dropdown options">
                                        <span class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fa fa-angle-right"></i>
                                        </span>
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                            <a class="dropdown-item" href="#">Week</a>
                                            <a class="dropdown-item" href="#">Month</a>
                                            <a class="dropdown-item" href="#">Year</a>
                                        </div>
                                    </div>
                                    <div class="metric-value d-inline-block">
                                        <h1 class="mb-1 text-primary">40,200</h1>
                                    </div>
                                    <div class="metric-label d-inline-block float-right text-danger"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <!-- /. metric -->
                        <!-- metric -->
                    </div>
                    <!-- /. metric -->
                    <!-- metric -->

                    <!-- /. metric -->

                    <!-- ============================================================== -->
                    <!-- revenue  -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <div class="col-xl-7 col-lg-12 col-md-7 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">
                                    Revenue
                                    <div class="dropdown">
                                        <span class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="fa fa-bars"></i>
                                        </span>
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                            <a class="dropdown-item" href="#">Week</a>
                                            <a class="dropdown-item" href="#">Month</a>
                                            <a class="dropdown-item" href="#">Year</a>
                                        </div>
                                    </div>
                                </h5>

                                <div class="card-body">
                                    <canvas id="revenue" width="400" height="150"></canvas>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end reveune  -->
                        <!-- ============================================================== -->
                        <!-- ============================================================== -->
                        <!-- total sale  -->
                        <!-- ============================================================== -->
                        <div class="col-xl-5 col-lg-12 col-md-5 col-sm-12 col-12">
                            <div class="card">
                                <div id="exTab1" class="container">
                                    <ul class="nav nav-pills">
                                        <li class="active">
                                            <a href="#1a" data-toggle="tab">Income</a>
                                        </li>
                                        <li><a href="#2a" data-toggle="tab">Commission</a></li>
                                    </ul>
                                    <div class="card-body">
                                        <div class="">
                                            <div class="tab-content clearfix">
                                                <div class="tab-pane active" id="1a">
                                                    <table class="table status">
                                                        <tr>
                                                            <td>Refferal Fee</td>
                                                            <td>:</td>
                                                            <td>₹ 4000</td>
                                                        </tr>
                                                        <tr>
                                                            <td>Pacakage Amount</td>
                                                            <td>:</td>
                                                            <td>₹ 6000</td>
                                                        </tr>
                                                        <tr>
                                                            <td>Commision Charges</td>
                                                            <td>:</td>
                                                            <td>₹ 10000</td>
                                                        </tr>
                                                    </table>
                                                </div>
                                                <div class="tab-pane" id="2a">
                                                    <table class="table status">
                                                        <tr>
                                                            <td>Refferal Commision</td>
                                                            <td>:</td>
                                                            <td>₹ 4000</td>
                                                        </tr>
                                                        <tr>
                                                            <td>Level Commision</td>
                                                            <td>:</td>
                                                            <td>₹ 6000</td>
                                                        </tr>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">New Members </h5>
                                <div class="card-body">
                                     <table class="table status">
                                        <thead>
                                            <th>S.No</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Mobile No</th>
                                            <th>Action</th>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>1</td>
                                                <td>Raja</td>
                                                <td>chandru@gmail.com</td>
                                                <td>9787654321</td>

                                                <td>
                                                    <a href="approval-view.php"><i class="fa fa-eye"></i></a>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>2</td>
                                                <td>Raju</td>
                                                <td>chandru@gmail.com</td>
                                                <td>9787654321</td>

                                                <td>
                                                    <a href="approval-view.php"><i class="fa fa-eye"></i></a>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>3</td>
                                                <td>Sekar</td>
                                                <td>sekar@gmail.com</td>
                                                <td>9787654321</td>

                                                <td>
                                                    <a href="approval-view.php"><i class="fa fa-eye"></i></a>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>4</td>
                                                <td>Somu</td>
                                                <td>chandru@gmail.com</td>
                                                <td>9787654321</td>

                                                <td>
                                                    <a href="approval-view.php"><i class="fa fa-eye"></i></a>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>5</td>
                                                <td>Raja</td>
                                                <td>chandru@gmail.com</td>
                                                <td>9787654321</td>

                                                <td>
                                                    <a href="approval-view.php"><i class="fa fa-eye"></i></a>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <nav aria-label="Page navigation example">
                                        <ul class="pagination">
                                            <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                                            <li class="page-item"><a class="page-link" href="#">1</a></li>
                                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                                            <li class="page-item"><a class="page-link" href="#">Next</a></li>
                                        </ul>
                                    </nav>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- footer -->
                <!-- ============================================================== -->
                <div class="footer">
                    <?php include 'footer.php';?>
                </div>
                <!-- ============================================================== -->
                <!-- end footer -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- end wrapper  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- end main wrapper  -->
        <!-- ============================================================== -->
        <!-- Optional JavaScript -->
        <!-- jquery 3.3.1 js-->
        <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
        <!-- bootstrap bundle js-->
        <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
        <!-- slimscroll js-->
        <script src="assets/vendor/slimscroll/jquery.slimscroll.js"></script>
        <!-- chartjs js-->
        <script src="assets/vendor/charts/charts-bundle/Chart.bundle.js"></script>
        <script src="assets/vendor/charts/charts-bundle/chartjs.js"></script>

        <!-- main js-->
        <script src="assets/libs/js/main-js.js"></script>
        <!-- jvactormap js-->
        <script src="assets/vendor/jvectormap/jquery-jvectormap-2.0.2.min.js"></script>
        <script src="assets/vendor/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
        <!-- sparkline js-->
        <script src="assets/vendor/charts/sparkline/jquery.sparkline.js"></script>
        <script src="assets/vendor/charts/sparkline/spark-js.js"></script>
        <!-- dashboard sales js-->
        <script src="assets/libs/js/dashboard-sales.js"></script>
    </body>
</html>
