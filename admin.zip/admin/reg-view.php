<!DOCTYPE html>
<html lang="en">
    <head>
      <?php include 'style.php';?>
    </head>

    <body>
        <!-- ============================================================== -->
        <!-- main wrapper -->
        <!-- ============================================================== -->
        <div class="dashboard-main-wrapper">
            <!-- ============================================================== -->
            <!-- navbar -->
            <!-- ============================================================== -->
            <div class="dashboard-header">
                <?php include 'nav.php';?>
            </div>
            <!-- ============================================================== -->
            <!-- end navbar -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- left sidebar -->
            <!-- ============================================================== -->
            <div class="nav-left-sidebar sidebar-dark">
                <div class="menu-list">
                    <?php include 'menu.php';?>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- end left sidebar -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- wrapper  -->
            <!-- ============================================================== -->
            <div class="dashboard-wrapper">
                <div class="container dashboard-content">
                    <!-- ============================================================== -->
                    <!-- pagehader  -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <h3 class="mb-2">Registration View</h3>

                                <div class="page-breadcrumb">
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">ASE Admin</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Registration View</li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">

                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="card">
                                        <ul class="actions">
                                             <li class="delete-user">
                                            <a href="#"><i class="fas fa-trash-alt"></i></a>
                                        </li>
                                        <li class="edit-user">
                                            <a href="edit-user.php"><i class="fas fa-pencil-alt"></i></a>
                                        </li>
                                       
                                    </ul>

                        </div>
                        </div>

                        <!-- ============================================================== -->
                        <!-- ap and ar balance  -->
                        <!-- ============================================================== -->
                        <div class="col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">Personal Details</h5>
                                <div class="card-body">
                                    <table class="table status">
                                        <tr>
                                            <th>Name</th>
                                            <td>Sekar</td>
                                        </tr>
                                        <tr>
                                            <th>Email</th>
                                            <td>asenterprises@gmail.com</td>
                                        </tr>
                                        <tr>
                                            <th>Mobile No</th>
                                            <td>9876543210</td>
                                        </tr>
                                        <tr>
                                            <th>Alternte Mobile No</th>
                                            <td>9876543210</td>
                                        </tr>
                                        <tr>
                                            <th>Father Name</th>
                                            <td>Otto</td>
                                        </tr>
                                        <tr>
                                            <th>Mother Name</th>
                                            <td>Thornton</td>
                                        </tr>
                                        <tr>
                                            <th>Gender</th>
                                            <td>Male</td>
                                        </tr>
                                        <tr>
                                            <th>Address</th>
                                            <td>No.167, Kathivakkam High Road, Ennore, Chennai-57</td>
                                        </tr>

                                        <tr>
                                            <th>State</th>
                                            <td>Tamilnadu</td>
                                        </tr>
                                        <tr>
                                            <th>Occupation</th>
                                            <td>Self Employed</td>
                                        </tr>
                                        <tr>
                                            <th>Business Type</th>
                                            <td>Industrial</td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end ap and ar balance  -->
                        <!-- ============================================================== -->
                        <!-- ============================================================== -->
                        <!-- gross profit  -->
                        <!-- ============================================================== -->
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">Bank Details</h5>
                                <div class="card-body">
                                    <table class="table status">
                                        <tr>
                                            <th>Pancard No</th>
                                            <td>ASDFE1234A</td>
                                        </tr>
                                        <tr>
                                            <th>Adhar No</th>
                                            <td>8845 2341 5634</td>
                                        </tr>
                                        <tr>
                                            <th>Bank Name</th>
                                            <td>Indian Bank</td>
                                        </tr>
                                        <tr>
                                            <th>Account No</th>
                                            <td>89071245000100</td>
                                        </tr>
                                        <tr>
                                            <th>IFSC Code</th>
                                            <td>ID1264D4</td>
                                        </tr>
                                        <tr>
                                            <th>Branch</th>
                                            <td>Chennai</td>
                                        </tr>
                                        <tr></tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end gross profit  -->
                        <!-- ============================================================== -->
                        <!-- ============================================================== -->
                        <!-- profit margin  -->
                        <!-- ============================================================== -->
                    </div>
                    <div class="row">
                        <!-- ============================================================== -->
                        <!-- ap and ar balance  -->
                        <!-- ============================================================== -->
                        <div class="col-xl-6 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">Invesment Details</h5>
                                <div class="card-body">
                                    <table class="table status">
                                        <tr>
                                            <th>Nominee</th>
                                            <td>ottto</td>
                                        </tr>
                                        <tr>
                                            <th>Relationship</th>
                                            <td>Father</td>
                                        </tr>
                                        <tr>
                                            <th>Nominee Contact No</th>
                                            <td>9876543210</td>
                                        </tr>
                                        <tr>
                                            <th>Nominee Email</th>
                                            <td>asent@gmail.com</td>
                                        </tr>
                                        <tr>
                                            <th>Refferal ID</th>
                                            <td>AS2021001</td>
                                        </tr>
                                        <tr>
                                            <th>Amount Investing</th>
                                            <td>₹ 10,000</td>
                                        </tr>
                                        
                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end ap and ar balance  -->
                        <!-- ============================================================== -->
                        <!-- ============================================================== -->
                        <!-- gross profit  -->
                        <!-- ============================================================== -->

                        <!-- ============================================================== -->
                        <!-- end gross profit  -->
                        <!-- ============================================================== -->
                        <!-- ============================================================== -->
                        <!-- profit margin  -->
                        <!-- ============================================================== -->
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- footer -->
                <!-- ============================================================== -->
                <div class="footer">
                   <?php include 'footer.php';?>
                </div>
                <!-- ============================================================== -->
                <!-- end footer -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- end wrapper  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- end main wrapper  -->
        <!-- ============================================================== -->
        <!-- Optional JavaScript -->
        <!-- jquery 3.3.1 js-->
        <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
        <!-- bootstrap bundle js-->
        <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
        <!-- slimscroll js-->
        <script src="assets/vendor/slimscroll/jquery.slimscroll.js"></script>
        <!-- chartjs js-->
        <script src="assets/vendor/charts/charts-bundle/Chart.bundle.js"></script>
        <script src="assets/vendor/charts/charts-bundle/chartjs.js"></script>

        <!-- main js-->
        <script src="assets/libs/js/main-js.js"></script>
        <!-- jvactormap js-->
        <script src="assets/vendor/jvectormap/jquery-jvectormap-2.0.2.min.js"></script>
        <script src="assets/vendor/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
        <!-- sparkline js-->
        <script src="assets/vendor/charts/sparkline/jquery.sparkline.js"></script>
        <script src="assets/vendor/charts/sparkline/spark-js.js"></script>
        <!-- dashboard sales js-->
        <script src="assets/libs/js/dashboard-sales.js"></script>
    </body>
</html>
