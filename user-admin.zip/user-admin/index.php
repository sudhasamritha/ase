₹ <!DOCTYPE html>
<html lang="en">
    <head>
        <?php include 'style.php';?>
    </head>

    <body>
        <!-- ============================================================== -->
        <!-- main wrapper -->
        <!-- ============================================================== -->
        <div class="dashboard-main-wrapper">
            <!-- ============================================================== -->
            <!-- navbar -->
            <!-- ============================================================== -->
            <div class="dashboard-header">
               <?php include 'nav.php';?>
            </div>
            <!-- ============================================================== -->
            <!-- end navbar -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- left sidebar -->
            <!-- ============================================================== -->
            <div class="nav-left-sidebar sidebar-dark">

                <div class="menu-list">
                <?php include 'menu.php';?>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- end left sidebar -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- wrapper  -->
            <!-- ============================================================== -->
            <div class="dashboard-wrapper">
                <div class="container dashboard-content">
                    <!-- ============================================================== -->
                    <!-- pagehader  -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="page-header">
                                <h3 class="mb-2">Dashboard</h3>

                                <div class="page-breadcrumb">
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="#" class="breadcrumb-link">ASE User Admin</a></li>
                                            <li class="breadcrumb-item active" aria-current="page"></li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- ============================================================== -->
                    <!-- pagehader  -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <!-- metric -->
                        <div class="col-lg-4 col-md-2 col-sm-12 col-12">
                            <div class="card user">
                                <div class="card-body"> 
                                    <h5 class="text-muted">Commission Earned</h5>
                                    <div class="metric-value d-inline-block">
                                        <h1 class="mb-1 text-primary">32,100</h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /. metric -->
                        <!-- metric -->
                        <div class="col-lg-4 col-md-2 col-sm-12 col-12">
                            <div class="card user">
                                <div class="card-body">
                                    <h5 class="text-muted">Payout Released</h5>
                                    <div class="metric-value d-inline-block">
                                        <h1 class="mb-1 text-primary">4,200</h1>
                                    </div>
                                    <div class="metric-label d-inline-block float-right text-danger"></div>
                                </div>
                            </div>
                        </div>
                        <!-- /. metric -->
                        <!-- metric -->
                        <div class="col-lg-4 col-sm-12 col-12">
                            <div class="card user">
                                <div class="card-body">
                                    <h5 class="text-muted">Payout Pending</h5>
                                    <div class="metric-value d-inline-block">
                                        <h1 class="mb-1 text-primary">5,656</h1>
                                    </div>
                                    <div class="metric-label d-inline-block float-right text-danger"></div>
                                </div>
                            </div>
                        </div>
                        <!-- metric -->
                        
                    </div>
                    <div class="row">
                        <!-- /. metric -->
                        <!-- metric -->
                    </div>
                    <!-- /. metric -->
                    <!-- metric -->

                    <!-- /. metric -->

                    <!-- ============================================================== -->
                    <!-- revenue  -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <div class="col-xl-7 col-lg-12 col-md-7 col-sm-12 col-12">
                            <div class="card">
                                <h5 class="card-header">
                                    New Members
                                    
                                </h5>

                                <div class="card-body">
                                    <table class="table status">
                                        <thead>
                                            <th>Id</th>
                                            <th>Name</th>
                                            <th>Joining Date</th>
                                        </thead>
                                                        <tr>
                                                            <td>ASE1001</td>
                                                            <td>Sampath</td>
                                                            <td>03/02/2021</td>
                                                        </tr>
                                                        <tr>
                                                            <td>ASE1002</td>
                                                            <td>Sampath</td>
                                                            <td>03/02/2021</td>
                                                        </tr>
                                                        <tr>
                                                           <td>ASE1003</td>
                                                            <td>Sampath</td>
                                                            <td>03/02/2021</td>
                                                        </tr>
                                                    </table>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end reveune  -->
                        <!-- ============================================================== -->
                        <!-- ============================================================== -->
                        <!-- total sale  -->
                        <!-- ============================================================== -->
                        <div class="col-xl-5 col-lg-12 col-md-5 col-sm-12 col-12">
                            <div class="card">
                                <div id="exTab1" class="container">
                                    <ul class="nav nav-pills">
                                        <li class="active">
                                            <a href="#1a" data-toggle="tab">Income</a>
                                        </li>
                                        <li><a href="#2a" data-toggle="tab">Commission</a></li>
                                    </ul>
                                    <div class="card-body">
                                        <div class="">
                                            <div class="tab-content clearfix">
                                                <div class="tab-pane active" id="1a">
                                                    <table class="table status">
                                                        <tr>
                                                            <td>Refferal Fee</td>
                                                            <td>:</td>
                                                            <td>₹ 4000</td>
                                                        </tr>
                                                        <tr>
                                                            <td>Pacakage Amount</td>
                                                            <td>:</td>
                                                            <td>₹ 6000</td>
                                                        </tr>
                                                        <tr>
                                                            <td>Commision Charges</td>
                                                            <td>:</td>
                                                            <td>₹ 10000</td>
                                                        </tr>
                                                    </table>
                                                </div>
                                                <div class="tab-pane" id="2a">
                                                    <table class="table status">
                                                        <tr>
                                                            <td>Refferal Commision</td>
                                                            <td>:</td>
                                                            <td>₹ 4000</td>
                                                        </tr>
                                                        <tr>
                                                            <td>Level Commision</td>
                                                            <td>:</td>
                                                            <td>₹ 6000</td>
                                                        </tr>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- ============================================================== -->
                        <!-- end total sale  -->
                        <!-- ============================================================== -->
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- footer -->
                <!-- ============================================================== -->
                <div class="footer">
                     <?php include 'footer.php';?>
                   
                </div>
                <!-- ============================================================== -->
                <!-- end footer -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- end wrapper  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- end main wrapper  -->
        <!-- ============================================================== -->
        <!-- Optional JavaScript -->
        <!-- jquery 3.3.1 js-->
        <script src="assets/vendor/jquery/jquery-3.3.1.min.js"></script>
        <!-- bootstrap bundle js-->
        <script src="assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
        <!-- slimscroll js-->
        <script src="assets/vendor/slimscroll/jquery.slimscroll.js"></script>
        <!-- chartjs js-->
        <script src="assets/vendor/charts/charts-bundle/Chart.bundle.js"></script>
        <script src="assets/vendor/charts/charts-bundle/chartjs.js"></script>

        <!-- main js-->
        <script src="assets/libs/js/main-js.js"></script>
        <!-- jvactormap js-->
        <script src="assets/vendor/jvectormap/jquery-jvectormap-2.0.2.min.js"></script>
        <script src="assets/vendor/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
        <!-- sparkline js-->
        <script src="assets/vendor/charts/sparkline/jquery.sparkline.js"></script>
        <script src="assets/vendor/charts/sparkline/spark-js.js"></script>
        <!-- dashboard sales js-->
        <script src="assets/libs/js/dashboard-sales.js"></script>
    </body>
</html>
