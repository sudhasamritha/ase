
                    <nav class="navbar navbar-expand-lg navbar-light">
                        <a class="d-xl-none d-lg-none" href="index.html">Dashboard</a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarNav">
                            <ul class="navbar-nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link" href="index.php"><i class="fa fa-fw fa-rocket"></i>Dashboard</a>
                                </li>
                                <li class="nav-item">
                                     <a class="nav-link" href="network.php"><i class="fa fa-fw fa-rocket"></i>Network</a>
                                </li>
                                    <li class="nav-item">
                                     <a class="nav-link" href="user-profile.php"><i class="fa fa-fw fa-rocket"></i>My Profile</a>
                                </li>
                            </ul>
                        </div>
                    </nav>